from pathlib import Path
import zipfile,hashlib,json,re,uuid
R=Path(__file__).resolve().parents[1]
S=R/"Assets/Package/V3/GPT's Buckingham Fountain in Motion.cok"
assert hashlib.sha256(S.read_bytes()).hexdigest()=='88d37d66fcb7d7a2cf1a8b405aa9e2b0f1ad00dd20a37f6093258d08daa1983d'
A=Path(r'H:/Games/GPT, Chicago AI Project/ACM - Maps/Chicago GPT/Assets/ChicagoAI/BFIMNativeWaterV4')
O=R/"Assets/Package/V4/GPT's Buckingham Fountain in Motion.cok";O.parent.mkdir(parents=True,exist_ok=True);assert not O.exists()
source=R/'Assets/Source/NativeV4';source.mkdir(parents=True,exist_ok=False)
kept={}
with zipfile.ZipFile(S) as old,zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as new:
 for info in old.infolist():
  data=old.read(info.filename)
  if info.filename=='GPTBuckinghamFountainInMotionV3.Prefab':
   txt=data.decode('utf-8-sig');assert txt.count('UnityGUID:9df86ceecc42a464986e80c3ba3c274a')==1 and txt.count('UnityGUID:6ee87921a1dc0404888222f31fb94335')==12
   txt=txt.replace('UnityGUID:9df86ceecc42a464986e80c3ba3c274a','CID:679d3c5e8a451361a17400090edcacd4').replace('UnityGUID:6ee87921a1dc0404888222f31fb94335','CID:2e6a05d20a1b9c1ed52e969c2409b298')
   data=txt.encode('utf8');(source/info.filename).write_bytes(data)
  elif info.filename=='package.deps.cid':data=uuid.uuid4().hex.encode()
  else:kept[info.filename]=hashlib.sha256(data).hexdigest()
  new.writestr(info,data)
 files=list(A.iterdir());assert len(files)==4
 for f in files:
  if f.name.endswith('.Prefab'):
   t=f.read_text(encoding='utf-8-sig');assert '"m_DisableDistanceCulling": true' in t and '"m_RequiredFlags": 0' in t and '"m_ForbiddenFlags": 0' in t
  new.write(f,f.name,compress_type=zipfile.ZIP_STORED);(source/f.name).write_bytes(f.read_bytes())
 pass
with zipfile.ZipFile(O) as z:
 assert z.testzip() is None and len(z.namelist())==54
 for n,h in kept.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 ids={z.read(n).decode('utf-8-sig').strip() for n in z.namelist() if n.endswith('.cid')}
 for n in z.namelist():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',z.read(n).decode('utf-8-sig')):assert cid in ids,(n,cid)
 assert not any(n.endswith('.dll') for n in z.namelist())
 deps=json.loads(z.read('package.deps').decode('utf-8-sig'));assert not deps['modDependencies'] and not deps['dlcDependencies']
receipt={'status':'assembled-and-verified','path':str(O),'sha256':hashlib.sha256(O.read_bytes()).hexdigest(),'bytes':O.stat().st_size,'entries':54,'crcPassed':True,'allCustomPrefabReferencesIncluded':True,'waterInitialization':'asset-local native water effects with independent distance culling','preservedPayloads':kept,'dependencies':deps}
(R/'Evidence/native-package-v004-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='preservedPayloads'}))
