from pathlib import Path
import zipfile,json,hashlib,re,uuid
R=Path(__file__).resolve().parents[1];G=Path('C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II');A=G/'ChicagoAI/BFIMV18Authoring'
h=lambda d:hashlib.sha256(d).hexdigest()
base=R/"Release/GPT's Buckingham Fountain, Animated.cok"
assert h(base.read_bytes())=='54ffa75f84fb024b083f39dbf560e95029302dd55e811e80fa6a5cdc2c8e5787'
source=json.loads((R/'Evidence/v018-perimeter-package.json').read_text());assert source['status']=='completed' and not source['mods'] and not source['dlc']
root=(A/'BFIMV18RootExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV18RootExport',"GPT's Buckingham Fountain, Animated").encode()
child=(A/'BFIMV18LightExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV18LightExport','BFIMNativeLightControllerV3').encode()
assert b'ObsoleteIdentifiers' in root and b"GPT's Buckingham Fountain in Motion" in root and b'8c4ee53137be5794b8f4cc6644b1f732' in root
assert child.count(b'"m_Duration": 120')==6 and b'"$rlength": 204' in child
with zipfile.ZipFile(base) as a,zipfile.ZipFile(source['path']) as b:
 assert a.testzip() is None and b.testzip() is None
 data={n:a.read(n) for n in a.namelist()};before={n:h(v) for n,v in data.items()}
 data['GPTBuckinghamFountainInMotionV3.Prefab']=root;data['BFIMNativeLightControllerV3.Prefab']=child;data['package.deps.cid']=uuid.uuid4().hex.encode()
 for n in b.namelist():
  if n in ('package.deps','package.deps.cid','BFIMPerimeterV18BPayload.Prefab','BFIMPerimeterV18BPayload.Prefab.cid'):continue
  target=n.replace('StreamingData~/TS512_MB3.MidMips','StreamingData~/BFIMPerimeterV18B/TS512_MB3.MidMips')
  assert target not in data,target
  data[target]=b.read(n)
 for n,digest in before.items():
  if n not in ('GPTBuckinghamFountainInMotionV3.Prefab','BFIMNativeLightControllerV3.Prefab','package.deps.cid'):assert h(data[n])==digest,n
 ids=[v.decode('utf-8-sig').strip() for n,v in data.items() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n,v in data.items():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',v.decode('utf-8-sig')):assert cid in ids,(n,cid)
 O=R/"Assets/Package/V18/GPT's Buckingham Fountain, Animated.cok";O.parent.mkdir(exist_ok=False)
 with zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
  for n,v in data.items():z.writestr(n,v)
with zipfile.ZipFile(O) as z:assert z.testzip() is None
receipt=dict(status='assembled-not-yet-reload-verified',path=str(O),sha256=h(O.read_bytes()),warmLights=60,temperature=2700,oldSaveNameAlias=True,allExistingWaterAndGeometryFilesUnchanged=True,crcPassed=True)
(R/'Evidence/native-package-v018-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
