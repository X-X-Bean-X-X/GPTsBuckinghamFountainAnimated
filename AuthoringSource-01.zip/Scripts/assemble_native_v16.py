from pathlib import Path
import zipfile,hashlib,json,re,uuid
R=Path(__file__).resolve().parents[1];G=Path(r'C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II')
S=R/"Assets/Package/V15/GPT's Buckingham Fountain in Motion.cok";old='e5b42e5df23501dfdc1851f4b7103b5c0b4c873875e0ee4df807c43998e1c29e'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(S)==old
A=G/'ChicagoAI/BFIMV16Authoring';T=R/'Assets/Source/NativeV16';T.mkdir(exist_ok=False)
child=(A/'BFIMV16LightExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV16LightExport','BFIMNativeLightControllerV3')
assert child.count('"m_Duration": 120')==6 and '"$rlength": 144' in child
replacements={'BFIMNativeLightControllerV3.Prefab':child.encode(),'package.deps.cid':uuid.uuid4().hex.encode()}
for p in A.glob('BFIMNativeLightV16*'):
 if p.is_file():replacements[p.name]=p.read_bytes()
assert len(replacements)==14, list(replacements)
O=R/"Assets/Package/V16/GPT's Buckingham Fountain in Motion.cok";O.parent.mkdir(exist_ok=False)
kept={}
with zipfile.ZipFile(S) as a,zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
 assert a.testzip() is None
 for n in a.namelist():
  d=replacements.get(n,a.read(n));z.writestr(n,d)
  if n not in replacements:kept[n]=hashlib.sha256(d).hexdigest()
 for n,d in replacements.items():
  if n not in a.namelist():z.writestr(n,d)
with zipfile.ZipFile(O) as z:
 assert z.testzip() is None
 ids=[z.read(n).decode('utf-8-sig').strip() for n in z.namelist() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n in z.namelist():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',z.read(n).decode('utf-8-sig')):assert cid in ids,(n,cid)
 for n,hsh in kept.items():assert hashlib.sha256(z.read(n)).hexdigest()==hsh
 deps=json.loads(z.read('package.deps').decode('utf-8-sig'));assert not deps['modDependencies'] and not deps['dlcDependencies']
for n,d in replacements.items():(T/n).write_bytes(d)
receipt=dict(status='assembled-for-clean-load',path=str(O),sha256=h(O),previousSha256=old,cycleSeconds=120,order=['Blue','Red','Green','Violet','White','HighlighterYellow'],belowFivePercentSeconds=.4,nearBlackSeconds=.008,waterAndGeometryUnchanged=True,lightEntries=144,crcPassed=True,preservedPayloads=kept)
(R/'Evidence/native-package-v016-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='preservedPayloads'}))
q=(R/'Scripts/BFIMQuitForV1520261023_v1.cs').read_text().replace('V15','V16').replace('v15','v16').replace(old,h(O))
(R/'Scripts/BFIMQuitForV1620261023_v1.cs').write_text(q)
s=(R/'Scripts/install_native_v15.py').read_text().replace('V15','V16').replace('v15','v16').replace('v014','v015').replace("old='7fa51d065ca2d71817c1543006ecf24c43404647243a13a47f9ff623b986f6b9';new='"+old+"'","old='"+old+"';new='"+h(O)+"'")
(R/'Scripts/install_native_v16.py').write_text(s)
