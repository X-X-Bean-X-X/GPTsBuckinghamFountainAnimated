from pathlib import Path
import bpy, math, json, shutil
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
D=R/'Assets/Import/BFIMOuterJetsV14'; D.mkdir(parents=True,exist_ok=False)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
height=12.5
base=.35
centers=[(32,0),(0,32),(-32,0),(0,-32)]

def tubes(lod):
    verts=[];faces=[];uv=[]
    steps=[64,32,16][lod];sides=[8,6,4][lod]
    for group,(cx,cy) in enumerate(centers):
        for strand in range(9 if lod==0 else 7 if lod==1 else 5):
            theta=math.tau*strand/9+group*.31
            lift=height if strand==0 else height-.14*strand
            spread=.14 if strand==0 else .18+.055*strand
            pts=[]
            for j in range(steps+1):
                t=j/steps
                radial=spread*t
                x=cx+math.cos(theta)*radial+.012*math.sin(t*33+strand)*math.sin(math.pi*t)
                y=cy+math.sin(theta)*radial+.012*math.cos(t*28+strand)*math.sin(math.pi*t)
                z=base+4*lift*t*(1-t)
                pts.append(Vector((x,y,z)))
            start=len(verts); length=0
            for j,p in enumerate(pts):
                tangent=(pts[min(j+1,steps)]-pts[max(j-1,0)]).normalized()
                a=tangent.cross(Vector((0,0,1)))
                if a.length<.001:a=tangent.cross(Vector((0,1,0)))
                a.normalize();b=tangent.cross(a).normalized()
                if j:length+=(p-pts[j-1]).length
                radius=(.052 if strand else .105)*(1+.22*math.sin(math.pi*j/steps))
                for k in range(sides):
                    verts.append(tuple(p+radius*(math.cos(k*math.tau/sides)*a+math.sin(k*math.tau/sides)*b)))
                    uv.append((k/sides,length*.6))
                if j:
                    for k in range(sides):
                        a0=start+(j-1)*sides+k;b0=start+(j-1)*sides+(k+1)%sides
                        faces.append((a0,b0,b0+sides,a0+sides))
    name='BFIMOuterJetsV14'+('_LOD'+str(lod) if lod else '')+'_Wat'
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
    ob=bpy.data.objects.new(name,me);scene.collection.objects.link(ob)
    mat=bpy.data.materials.new(name);mat.diffuse_color=(.7,.88,.95,.5);me.materials.append(mat)
    layer=me.uv_layers.new(name='UVMap')
    for poly in me.polygons:
        poly.use_smooth=True
        for li in poly.loop_indices:layer.data[li].uv=uv[me.loops[li].vertex_index]
    return ob

def export(ob,name):
    bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
    tri=ob.modifiers.new('Triangles','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
    bpy.ops.export_scene.fbx(filepath=str(D/(name+'.fbx')),use_selection=True,object_types={'MESH'},apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,bake_anim=False)
    return {'name':name,'triangles':len(ob.data.polygons),'bounds':list(ob.dimensions)}

checks=[]
for lod in range(3):
    name='BFIMOuterJetsV14'+('_LOD'+str(lod) if lod else '')
    parts=[]
    for cx,cy in centers:
        bpy.ops.mesh.primitive_cylinder_add(vertices=12 if lod==0 else 8,radius=.13,depth=.08,location=(cx,cy,.31))
        parts.append(bpy.context.object)
    bpy.ops.object.select_all(action='DESELECT')
    for o in parts:o.select_set(True)
    bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();o=bpy.context.object;o.name=o.data.name=name
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
    mat=bpy.data.materials.new(name);mat.diffuse_color=(.2,.13,.08,1);o.data.materials.append(mat)
    for poly in o.data.polygons:
        for li in poly.loop_indices:o.data.uv_layers.active.data[li].uv=(.7,.5)
    checks.append(export(o,name));ob=tubes(lod);checks.append(export(ob,ob.name))
    for suffix in ('BaseColor','Normal','MaskMap','ControlMask'):
        shutil.copy2(R/'Assets/Import/BFIMDetailsV10'/('BFIMDetailsV10_'+suffix+'.png'),D/(name+'_'+suffix+'.png'))
    for suffix in ('BaseColor','Normal'):
        shutil.copy2(R/'Assets/Import/BFIMDetailsV10'/('BFIMDetailsV10_Wat_'+suffix+'.png'),D/(name+'_Wat_'+suffix+'.png'))
scene['outerJetHeightMetres']=height;scene['status']='native flow water geometry, not yet game verified'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Working/Buckingham_Fountain_outer_jets_v014.blend'))
(R/'Evidence/outer-jets-v014-export.json').write_text(json.dumps({'heightMetres':height,'baseMetres':base,'centers':centers,'meshes':checks},indent=2))
print(json.dumps(checks))
