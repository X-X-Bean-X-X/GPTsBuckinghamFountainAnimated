"""Photo-guided water paths and landscape additions; original geometry is read only."""
from pathlib import Path
import bpy,bmesh,json,math,random,shutil
import numpy as np
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(R/'Working/Buckingham_Fountain_in_Motion_source_v003_taller_tiers.blend'))
scene=bpy.context.scene
D=R/'Assets/Import/BFIMDetailsV10';D.mkdir(parents=True,exist_ok=True)
col=bpy.data.collections.new('07 Reference corrections V5');scene.collection.children.link(col)
solid=[];waters=[];layout=[];waterTubeSpecs=[];waterSheetSpecs=[];recordWater=True
random.seed(133)
T=math.tau
colors=[(.075,.19,.026,1),(.025,.042,.033,1),(.53,.40,.31,1),(.19,.15,.07,1),(.57,.42,.36,1)]
mats=[]
for i,c in enumerate(colors):
 m=bpy.data.materials.new(['V5 Grass','V5 Loop railing','V5 Coping','V5 Bronze nozzles','V5 Pink paving'][i]);m.diffuse_color=c;m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=c;bs.inputs['Roughness'].default_value=.83 if i in (0,4) else .55;bs.inputs['Metallic'].default_value=.65 if i in (1,3) else 0;mats.append(m)
wm=bpy.data.materials.new('V5 Moving streams');wm.use_nodes=True;wm.diffuse_color=(.68,.86,.94,.5)
bs=wm.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.68,.86,.94,1);bs.inputs['Transmission Weight'].default_value=.35;bs.inputs['Roughness'].default_value=.22

def mesh(name,v,f,mat,uvs=None,water=False):
 if water and recordWater and 'continuous overflow veil' in name:waterSheetSpecs.append((name,list(v),list(f),list(uvs)))
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);col.objects.link(o);me.materials.append(wm if water else mats[mat]);u=me.uv_layers.new(name='UVMap')
 for p in me.polygons:
  p.use_smooth=True
  for li in p.loop_indices:
   vi=me.loops[li].vertex_index;co=me.vertices[vi].co
   u.data[li].uv=uvs[vi] if uvs else ((mat+.08+(co.x*.07% .84))/5,.08+(co.y*.09% .84))
 (waters if water else solid).append(o);return o

def tube(name,pts,radius,mat=3,sides=8,water=False):
 if water and recordWater:waterTubeSpecs.append((name,list(pts),list(radius) if isinstance(radius,list) else radius,sides))
 v=[];uv=[];f=[];length=0
 for j,p in enumerate(pts):
  p=Vector(p);direction=Vector(pts[min(j+1,len(pts)-1)])-Vector(pts[max(j-1,0)]);direction.normalize();axis=direction.cross(Vector((0,0,1)))
  if axis.length<.001:axis=direction.cross(Vector((0,1,0)))
  axis.normalize();other=direction.cross(axis).normalized()
  if j:length+=(p-Vector(pts[j-1])).length
  rad=radius[j] if isinstance(radius,list) else radius
  for k in range(sides):
   v.append(tuple(p+rad*(math.cos(k*T/sides)*axis+math.sin(k*T/sides)*other)));uv.append((k/sides,length*.6))
  if j:
   for k in range(sides):
    a=(j-1)*sides+k;b=(j-1)*sides+(k+1)%sides;f.append((a,b,b+sides,a+sides))
 return mesh(name,v,f,mat,uv if water else None,water)

def radial(r,a,z):return (r*math.cos(a),r*math.sin(a),z)
def nozzle(name,p,direction=(0,0,1)):
 p=Vector(p);d=Vector(direction).normalized();tube(name+' bronze pipe',[tuple(p-d*.18),tuple(p+d*.05)],.055,3,10)
 tube(name+' flange',[tuple(p-d*.17),tuple(p-d*.13)],.11,3,12)

def arc(name,start,end,lift,width=.07,group='tier-arcs'):
 pts=[]
 for j in range(33):
  t=j/32;p=Vector(start).lerp(Vector(end),t);p.z+=4*lift*t*(1-t);pts.append(tuple(p))
 rs=[width*(.85+.5*j/32)*(1+.12*math.sin(j*1.8)) for j in range(33)]
 tube(name,pts,rs,water=True);nozzle(name,start,Vector(pts[1])-Vector(start));layout.append({'name':name,'group':group,'start':list(start),'end':list(end),'lift':lift,'representation':'native-flow-water-mesh'})
 # Two narrow broken strands catch the light without turning the stream into a solid rod.
 for strand in range(2):
  for seg in range(5):
   startj=5+seg*5;chunk=[]
   for j in range(startj,min(startj+4,33)):
    p=Vector(pts[j]);p.x+=math.sin(j*2.7+strand)*width*1.2;p.y+=math.cos(j*2.1+strand)*width*1.2;chunk.append(tuple(p))
   if len(chunk)>1:tube(name+' droplets '+str(strand)+'-'+str(seg),chunk,width*.3,water=True,sides=4)

# Match the existing mapped coping exactly before extending its outline.
coping=bpy.data.objects['Mapped outer basin coping - 85.344 m'];n=len(coping.data.vertices)//7
outline=[(coping.matrix_world@v.co).xy[:] for v in list(coping.data.vertices)[:n]]
def off(p,d,z):
 x,y=p;r=math.hypot(x,y);return(x*(1+d/r),y*(1+d/r),z)
def strip(name,d1,d2,z,mat):
 v=[off(p,d1,z) for p in outline]+[off(p,d2,z) for p in outline];f=[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 if (Vector(v[f[0][1]])-Vector(v[f[0][0]])).cross(Vector(v[f[0][2]])-Vector(v[f[0][0]])).z<0:f=[tuple(reversed(x)) for x in f]
 return mesh(name,v,f,mat)
strip('Lobed grass border',.03,3.0,.035,0)
strip('Outer stone curb',3.0,3.18,.065,2)
strip('Pink perimeter paving',3.18,4.6,.018,4)
for d,z in [(3.08,.09)]:tube('Continuous outer curb',[off(p,d,z) for p in outline]+[off(outline[0],d,z)],.065,2,6)
# Ground photographs show low repeating rounded loops, not a tall picket fence.
rail=[Vector(off(p,2.72,.06)) for p in outline];lens=[(rail[(i+1)%n]-rail[i]).length for i in range(n)];perimeter=sum(lens)
def at(s):
 s%=perimeter
 for i,l in enumerate(lens):
  if s<=l:return rail[i].lerp(rail[(i+1)%n],s/l)
  s-=l
 return rail[0]
loops=round(perimeter/.85);spacing=perimeter/loops
for i in range(loops):
 a=at(i*spacing);b=at((i+1)*spacing);pts=[tuple(a),tuple(a+Vector((0,0,.48)))]
 for j in range(13):
  t=j/12;p=a.lerp(b,t);p.z+=.48+.31*math.sin(math.pi*t);pts.append(tuple(p))
 pts.extend([tuple(b+Vector((0,0,.48))),tuple(b)]);tube('Perimeter loop %03d'%i,pts,.018,1,6)
 if i%4==0:tube('Fence anchor %03d'%i,[tuple(a-Vector((0,0,.08))),tuple(a+Vector((0,0,.65)))],.032,1,8)
tube('Low continuous fence tie',[tuple(p+Vector((0,0,.25))) for p in rail]+[tuple(rail[0]+Vector((0,0,.25)))],.016,1,6)
# 36 inward arcs: twelve per tier; heights follow the user's 25 percent increase.
for tier,r0,z0,r1,z1,lift in [('lower',20.1,.35,15.1,3.05,3.1),('middle',12.8,3.08,8.6,5.86,2.9),('upper',6.5,5.85,3.1,9.52,3.0)]:
 for i in range(12):
  a=(i+.5)*T/12;arc(tier+' inward arc %02d'%i,radial(r0,a,z0),radial(r1,a,z1),lift,.075)
# 34 outward console jets: lower 12, middle 12, upper 10.
for tier,r0,z0,r1,z1,lift,count in [('lower',15.26,3.38,22,.29,1.7,12),('middle',8.68,6.28,13.3,3.04,1.6,12),('upper',3.1,9.58,6.8,5.8,1.3,10)]:
 for i in range(count):
  a=i*T/count;arc(tier+' console stream %02d'%i,radial(r0,a,z0),radial(r1,a,z1),lift,.07,'console-jets')
# Mouth locations follow the existing editable sea-horse sculptural geometry.
for g in range(4):
 a=math.pi/4+g*math.pi/2
 for side in [-1,1]:
  x=side*3.77;y=26.1+1.49;start=(math.cos(a)*y-math.sin(a)*x,math.sin(a)*y+math.cos(a)*x,.25+3.1)
  end=radial(16.4,a+side*.13,.29);arc('Sea-horse mouth %d-%d'%(g,side),start,end,4.0,.11,'sea-horse-jets')
# Crowning and isolated spray heads become separate animated native particle emitters.
layout.append({'name':'Central geyser','group':'central','start':[0,0,9.6],'scale':[1,1,1],'representation':'native-particles'})
for i in range(34):
 a=i*T/34;p=radial(2.55,a,9.6);end=radial(2.88,a+.035,9.55)
 arc('Crown %02d'%i,p,end,2.8+(i%3)*.12,.065,'crown')
for g in range(4):
 a=g*T/4;center=Vector(radial(32,a,.32))
 for j in range(5):
  p=center.copy();aa=a+(j-1)*T/4
  if j:p+=Vector((math.cos(aa)*.65,math.sin(aa)*.65,0))
  end=p+Vector((math.cos(aa)*(.35 if j==0 else .9),math.sin(aa)*(.35 if j==0 else .9),-.05))
  arc('Outer spray %d-%d'%(g,j),p,end,4.5 if j==0 else 2.6,.12 if j==0 else .085,'outer-five-head')
# Continuous gently rippled spill curtains preserve relief without striped gaps.
for tag,r,top,bottom,count in [('lower',15.70,3.13,.28,160),('middle',9.14,5.99,3.04,100),('upper',3.6576,9.76,5.84,64)]:
 v=[];uv=[];f=[]
 for j in range(9):
  t=j/8
  for i in range(count+1):
   a=i*T/count;rr=r+.06+.2*t*t+.018*math.sin(a*19+j*.6);z=top+(bottom-top)*t
   v.append(radial(rr,a,z));uv.append((i/count*12,t*(top-bottom)*1.6))
  if j:
   for i in range(count):
    k=(j-1)*(count+1)+i;f.append((k,k+count+1,k+count+2,k+1))
 mesh(tag+' continuous overflow veil',v,f,0,uv,True)
assert len(layout)==133,len(layout)
(R/'Docs/jet-layout-v005.json').write_text(json.dumps({'basis':'Park District group counts; photo-estimated nozzle positions and trajectories','jets':layout,'railingLoops':loops,'grassWidthMetres':3.0,'outerAdditionMetres':4.6},indent=2))

def activate(o):
 bpy.ops.object.select_all(action='DESELECT');o.hide_set(False);o.select_set(True);bpy.context.view_layer.objects.active=o

def join(objs,name):
 for o in objs:o.select_set(False)
 bpy.ops.object.select_all(action='DESELECT')
 for o in objs:o.select_set(True)
 bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object;o.name=o.data.name=name;bpy.ops.object.transform_apply(location=True,rotation=True,scale=True);return o
solid=join(solid,'BFIMDetailsV10');water=join(waters,'BFIMDetailsV10_Wat')
# Authored texture atlas uses UV bands for grass, dark metal, stone, brass and paving.
res=2048;rng=np.random.default_rng(133);pix=np.ones((res,res,4),dtype=np.float32)
for i,c in enumerate(colors):
 x0=round(i*res/5);x1=round((i+1)*res/5);noise=rng.uniform(.72,1.2,(res,x1-x0,1));pix[:,x0:x1,:3]=np.clip(np.array(c[:3])[None,None,:]*noise,0,1)
 if i==4:
  for yy in range(0,res,64):pix[yy:yy+2,x0:x1,:3]*=.8
# Blender stores linear pixels and PNG converts to sRGB; matching diffuse values by design.
def saveim(name,p,noncolor=False):
 im=bpy.data.images.new(name,width=res,height=res,alpha=True);im.colorspace_settings.name='Non-Color' if noncolor else 'sRGB';im.pixels.foreach_set(p.ravel());im.filepath_raw=str(D/(name+'.png'));im.file_format='PNG';im.save();return im
base=saveim('BFIMDetailsV10_BaseColor',pix)
mask=np.zeros_like(pix);mask[:,:,3]=.17
for i in [1,3]:mask[:,round(i*res/5):round((i+1)*res/5),0]=.6;mask[:,round(i*res/5):round((i+1)*res/5),3]=.45
saveim('BFIMDetailsV10_MaskMap',mask,True);saveim('BFIMDetailsV10_ControlMask',np.zeros_like(pix),True)
norm=np.ones_like(pix);norm[:,:,0:2]=.5;saveim('BFIMDetailsV10_Normal',norm,True)
sm=bpy.data.materials.new('BFIMDetailsV10');sm.use_nodes=True;tex=sm.node_tree.nodes.new('ShaderNodeTexImage');tex.image=base;sm.node_tree.links.new(tex.outputs['Color'],sm.node_tree.nodes.get('Principled BSDF').inputs['Base Color']);solid.data.materials.clear();solid.data.materials.append(sm)
for p in solid.data.polygons:p.material_index=0
water.name=water.data.name='BFIMDetailsV10_Wat';water.data.materials.clear();watmat=bpy.data.materials.new('BFIMDetailsV10_Wat');watmat.use_nodes=True;watmat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.7,.88,.95,1);water.data.materials.append(watmat)
for p in water.data.polygons:p.material_index=0
# Fine elongated normal waves scroll along stream UVs in the native water shader.
y,x=np.mgrid[0:res,0:res];normal=np.ones_like(pix);normal[:,:,0]=.5+.16*np.sin(x*.11+y*.047);normal[:,:,1]=.5+.2*np.sin(y*.17+np.sin(x*.08));normal[:,:,2]=np.sqrt(np.maximum(.01,1-(normal[:,:,0]*2-1)**2-(normal[:,:,1]*2-1)**2))*.5+.5
saveim('BFIMDetailsV10_Wat_Normal',normal,True)
wbase=np.ones_like(pix);wbase[:,:,:]=[.7,.88,.95,.5];saveim('BFIMDetailsV10_Wat_BaseColor',wbase)
checks=[]
recordWater=False
for original,wat in [(solid,False),(water,True)]:
 basename=original.name;original.name=original.data.name='SOURCE_'+basename
 for lod,ratio in [(0,1),(1,.45),(2,.12)]:
  name='BFIMDetailsV10'+('_LOD'+str(lod) if lod else '')+('_Wat' if wat else '')
  if wat and lod:
   waters=[];step=2 if lod==1 else 4;sides=6 if lod==1 else 4
   for label,pts,rad,oldSides in waterTubeSpecs:
    if 'droplets' in label:continue
    ids=list(range(0,len(pts),step))
    if ids[-1]!=len(pts)-1:ids.append(len(pts)-1)
    tube(label+' LOD'+str(lod),[pts[k] for k in ids],[rad[k] for k in ids] if isinstance(rad,list) else rad,water=True,sides=sides)
   for label,vs,faces,uvs in waterSheetSpecs:mesh(label+' LOD'+str(lod),vs,faces,0,uvs,True)
   cp=join(waters,name);cp.data.materials.clear();cp.data.materials.append(watmat)
   for p in cp.data.polygons:p.material_index=0
  else:
   cp=original.copy();cp.data=original.data.copy();col.objects.link(cp);cp.name=cp.data.name=name
  activate(cp)
  if lod and not wat:mod=cp.modifiers.new('LOD','DECIMATE');mod.ratio=ratio;bpy.ops.object.modifier_apply(modifier=mod.name)
  tri=cp.modifiers.new('Triangles','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
  bpy.ops.export_scene.fbx(filepath=str(D/(name+'.fbx')),use_selection=True,object_types={'MESH'},apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,bake_anim=False)
  if lod:
   for suffix in (['BaseColor','Normal'] if wat else ['BaseColor','MaskMap','ControlMask','Normal']):shutil.copy2(D/(basename+'_'+suffix+'.png'),D/(name+'_'+suffix+'.png'))
  checks.append({'name':name,'triangles':len(cp.data.polygons),'dimensions':list(cp.dimensions)});me=cp.data;bpy.data.objects.remove(cp,do_unlink=True);bpy.data.meshes.remove(me)
scene['v5_status']='Additional geometry exported; native animation integration and visual QA pending.'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Working/Buckingham_Fountain_in_Motion_source_v010_details.blend'))
(R/'Evidence/details-v010-export.json').write_text(json.dumps({'status':'exported-not-game-verified','jets':len(layout),'meshes':checks},indent=2))
print(json.dumps(checks),flush=True)
