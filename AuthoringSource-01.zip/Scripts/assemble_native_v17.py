from pathlib import Path
import zipfile,json,hashlib,re,uuid
R=Path(__file__).resolve().parents[1];G=Path('C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II')
h=lambda d:hashlib.sha256(d).hexdigest()
base=R/"Assets/Package/GPT's Buckingham Fountain in Motion.cok"
assert h(base.read_bytes())=='7c3b6fee1f44590c070291109edc207801b6bbb10b74d958bdd01fbcc4d67404'
source=json.loads((R/'Evidence/v017-details-package.json').read_text());assert source['status']=='completed' and not source['mods'] and not source['dlc']
root=(G/'ChicagoAI/BFIMV17Authoring/BFIMV17RootExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV17RootExport',"GPT's Buckingham Fountain in Motion").encode()
assert root.count(b'CID:679d3c5e8a451361a17400090edcacd4')==1
assert b'CID:f2b04887f0427b25af67b7c13436674e' in root
assert b'"m_Duration": 120' in root
assert root.count(b'CID:2e6a05d20a1b9c1ed52e969c2409b298')==4
T=R/'Assets/Source/NativeV17';T.mkdir(exist_ok=False);(T/'GPTBuckinghamFountainInMotionV3.Prefab').write_bytes(root)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(source['path']) as b:
 assert a.testzip() is None and b.testzip() is None
 data={n:a.read(n) for n in a.namelist()}
 before={n:h(v) for n,v in data.items()}
 data['GPTBuckinghamFountainInMotionV3.Prefab']=root;data['package.deps.cid']=uuid.uuid4().hex.encode()
 added={}
 for n in b.namelist():
  if n in ('package.deps','package.deps.cid','BFIMDetailsV17Payload.Prefab','BFIMDetailsV17Payload.Prefab.cid'):continue
  target=n.replace('StreamingData~/TS512_MB3.MidMips','StreamingData~/BFIMDetailsV17/TS512_MB3.MidMips')
  assert target not in data,target
  data[target]=b.read(n);added[target]=h(data[target])
 for n,digest in before.items():
  if n not in ('GPTBuckinghamFountainInMotionV3.Prefab','package.deps.cid'):assert h(data[n])==digest,n
 ids=[v.decode('utf-8-sig').strip() for n,v in data.items() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n,v in data.items():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',v.decode('utf-8-sig')):assert cid in ids,(n,cid)
 O=R/"Assets/Package/V17/GPT's Buckingham Fountain in Motion.cok";O.parent.mkdir(exist_ok=False)
 with zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
  for n,v in data.items():z.writestr(n,v)
with zipfile.ZipFile(O) as z:assert z.testzip() is None
receipt=dict(status='assembled',path=str(O),sha256=h(O.read_bytes()),previousSha256=h(base.read_bytes()),railingHeightMetres=1.10,railingHorizontalRails=2,outerNativeEffects=4,centralNativeEffects=1,lightingPreservedByteForByte=True,cycleSeconds=120,addedFiles=added,crcPassed=True)
(R/'Evidence/native-package-v017-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='addedFiles'}))
