import json,hashlib,shutil,zipfile
from pathlib import Path
r=Path(__file__).resolve().parents[1];n='Chicago GPT - BFIM Building Validation 20261024'
s=Path('C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II/Saves/76561198025517208')/(n+'.cok');d=r/'Recovery/MapCheckpoints'/(n+'.cok')
with zipfile.ZipFile(s) as z: assert z.testzip() is None
assert not d.exists();shutil.copy2(s,d)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(s)==h(d)
a={'saveName':n,'expectedSaveSHA256':h(s),'expectedFrame':1781221,'expectedSession':'b37026a69ad44087b47a1221ff577ea1','confirmation':'Load verified fountain map'}
(r/'Prototype/original-reload.json').write_text(json.dumps(a))
print(json.dumps(a))
