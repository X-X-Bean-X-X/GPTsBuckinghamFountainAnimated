"""Bake PBR textures, create LODs, export native-import candidates and previews.
Run after build_fountain.py; exports remain candidates until tested in CS2.
"""
import argparse
import json
import math
import sys
from pathlib import Path

import bpy
import bmesh
import numpy as np
from mathutils import Vector

parser=argparse.ArgumentParser()
parser.add_argument('--root',default=str(Path(__file__).resolve().parents[1]))
parser.add_argument('--render',action='store_true')
parser.add_argument('--resolution',type=int,default=4096)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
root=Path(args.root)
bpy.ops.wm.open_mainfile(filepath=str(root/'Working'/'Buckingham_Fountain_in_Motion_source_v003_taller_tiers.blend'))
scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=8
scene.render.bake.margin=12
scene.render.bake.use_selected_to_active=False
try:
    prefs=bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type='OPTIX';prefs.get_devices()
    for dev in prefs.devices:dev.use=dev.type=='OPTIX'
    if any(d.type=='OPTIX' for d in prefs.devices):scene.cycles.device='GPU'
except Exception as e:print('GPU setup: '+str(e),flush=True)
dest=root/'Assets'/'Import'/'BFIMTallV03'
dest.mkdir(parents=True,exist_ok=True)
old_export=bpy.data.collections.get('80 Game export meshes')
if old_export:
    for old_obj in list(old_export.objects):bpy.data.objects.remove(old_obj,do_unlink=True)
    bpy.data.collections.remove(old_export)
export_col=bpy.data.collections.new('80 Game export meshes')
scene.collection.children.link(export_col)
source_cols=[c for c in scene.collection.children if c.name[0] in '0123456' and c!=export_col]
source_objs=[o for c in source_cols for o in c.objects if o.type=='MESH']


def activate(obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.hide_set(False);obj.select_set(True);bpy.context.view_layer.objects.active=obj


def duplicate_meshes(objects,name):
    copies=[]
    for obj in objects:
        cp=obj.copy();cp.data=obj.data.copy();export_col.objects.link(cp);copies.append(cp)
    bpy.ops.object.select_all(action='DESELECT')
    for cp in copies:cp.select_set(True)
    bpy.context.view_layer.objects.active=copies[0]
    bpy.ops.object.join()
    obj=bpy.context.object;obj.name=name;obj.data.name=name
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
    bm=bmesh.new();bm.from_mesh(obj.data)
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=0.00003)
    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=0.000001)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(obj.data);bm.free();obj.data.update()
    return obj


water_source=[o for o in source_objs if any(m and m.name.startswith('BFIM - Rich blue basin water') for m in o.data.materials)]
floor_source=[o for o in source_objs if o.name=='Basin floor']
solid_source=[o for o in source_objs if o not in water_source and o not in floor_source]
solid=duplicate_meshes(solid_source,'BFIMTallV03')
activate(solid)
bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.uv.smart_project(angle_limit=math.radians(70),island_margin=0.004,scale_to_bounds=True)
bpy.ops.object.mode_set(mode='OBJECT')
for uv in solid.data.uv_layers.active.data:uv.uv=uv.uv*0.93+Vector((0.055,0.055))
floor=duplicate_meshes(floor_source,'Floor bake patch')
uv= floor.data.uv_layers.new(name='UVMap')
for loop in floor.data.loops:
    p=floor.data.vertices[loop.vertex_index].co
    uv.data[loop.index].uv=(0.024+p.x/85.344*0.035,0.024+p.y/85.344*0.035)
activate(solid);floor.select_set(True);bpy.ops.object.join()
solid.data.name=solid.name='BFIMTallV03'
print('BF_UV_READY',flush=True)
for o in source_objs:o.hide_render=True
for c in source_cols:c.hide_render=True


def image(name,noncolor=False):
    im=bpy.data.images.new(name,width=args.resolution,height=args.resolution,alpha=True,float_buffer=False)
    im.colorspace_settings.name='Non-Color' if noncolor else 'sRGB'
    return im


def bake_emit(obj,name,kind):
    activate(obj)
    target=image(name,kind!='color')
    saved=[]
    for mat in obj.data.materials:
        nt=mat.node_tree;n=nt.nodes;links=nt.links
        out=next(x for x in n if x.type=='OUTPUT_MATERIAL')
        bs=next(x for x in n if x.type=='BSDF_PRINCIPLED')
        old=[(l.from_socket,l.to_socket) for l in list(out.inputs['Surface'].links)]
        emit=n.new('ShaderNodeEmission')
        emit.inputs['Strength'].default_value=1
        if kind=='color':
            if bs.inputs['Base Color'].is_linked:links.new(bs.inputs['Base Color'].links[0].from_socket,emit.inputs[0])
            else:emit.inputs[0].default_value=bs.inputs['Base Color'].default_value
        elif kind=='metal_rough':
            emit.inputs[0].default_value=(bs.inputs['Metallic'].default_value,0,1-bs.inputs['Roughness'].default_value,1)
        else:
            emit.inputs[0].default_value=(0,0,0,1)
        links.new(emit.outputs[0],out.inputs[0])
        tex=n.new('ShaderNodeTexImage');tex.image=target;n.active=tex
        saved.append((nt,out,old,emit,tex))
    bpy.ops.object.bake(type='EMIT')
    for nt,out,old,emit,tex in saved:
        nt.nodes.remove(emit);nt.nodes.remove(tex)
        for a,b in old:nt.links.new(a,b)
    print('BF_BAKED '+name,flush=True)
    return target


def save(im,path):
    im.filepath_raw=str(path);im.file_format='PNG';im.save()


base=bake_emit(solid,'BFIMTallV03_BaseColor','color')
save(base,dest/'BFIMTallV03_BaseColor.png')
mr=bake_emit(solid,'MetalGloss bake','metal_rough')
raw=np.empty(args.resolution*args.resolution*4,dtype=np.float32)
mr.pixels.foreach_get(raw);raw=raw.reshape((-1,4))
mask_pixels=np.zeros_like(raw);mask_pixels[:,0]=raw[:,0];mask_pixels[:,3]=raw[:,2]
mask=image('BFIMTallV03_MaskMap',True);mask.pixels.foreach_set(mask_pixels.ravel())
save(mask,dest/'BFIMTallV03_MaskMap.png')
control=image('BFIMTallV03_ControlMask',True)
control.pixels.foreach_set(np.zeros_like(raw).ravel());save(control,dest/'BFIMTallV03_ControlMask.png')
normal=image('BFIMTallV03_Normal',True)
normal_pixels=np.zeros_like(raw);normal_pixels[:,0:2]=0.5;normal_pixels[:,2:]=1
normal.pixels.foreach_set(normal_pixels.ravel());save(normal,dest/'BFIMTallV03_Normal.png')
# Native lights are configured in CS2; omit the blank emissive ID map.


# Replace procedural materials on the export object with the baked PBR material.
mat=bpy.data.materials.new('BFIMTallV03');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');nt=mat.node_tree
tex=nt.nodes.new('ShaderNodeTexImage');tex.image=base;nt.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
texmask=nt.nodes.new('ShaderNodeTexImage');texmask.image=mask
sep=nt.nodes.new('ShaderNodeSeparateColor');nt.links.new(texmask.outputs['Color'],sep.inputs[0])
nt.links.new(sep.outputs['Red'],bs.inputs['Metallic'])
inv=nt.nodes.new('ShaderNodeMath');inv.operation='SUBTRACT';inv.inputs[0].default_value=1
nt.links.new(texmask.outputs['Alpha'],inv.inputs[1]);nt.links.new(inv.outputs[0],bs.inputs['Roughness'])
solid.data.materials.clear();solid.data.materials.append(mat)
for p in solid.data.polygons:p.material_index=0
water=duplicate_meshes(water_source,'BFIMTallV03_Wat')
water_uv=water.data.uv_layers.new(name='UVMap')
for loop in water.data.loops:
    p=water.data.vertices[loop.vertex_index].co
    water_uv.data[loop.index].uv=(0.5+p.x/90,0.5+p.y/90)
water_mat=bpy.data.materials.new('BFIMTallV03_Wat');water_mat.use_nodes=True
water_bs=water_mat.node_tree.nodes.get('Principled BSDF')
water_bs.inputs['Base Color'].default_value=(0.06,0.38,0.62,1)
water_bs.inputs['Roughness'].default_value=0.14
water.data.materials.clear();water.data.materials.append(water_mat)
for p in water.data.polygons:p.material_index=0
water_base=image('BFIMTallV03_Wat_BaseColor')
wp=np.zeros_like(raw);wp[:,:]=[0.06,0.38,0.62,1]
water_base.pixels.foreach_set(wp.ravel());save(water_base,dest/'BFIMTallV03_Wat_BaseColor.png')


def export(obj,path):
    activate(obj)
    bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},
        apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',
        bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',
        use_tspace=True,add_leaf_bones=False,bake_anim=False,path_mode='AUTO')


stats=[]
for obj,basename in [(solid,'BFIMTallV03'),(water,'BFIMTallV03_Wat')]:
    activate(obj)
    tri=obj.modifiers.new('Game triangulation','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
    obj.name=obj.data.name='SOURCE_'+basename
    for lod,ratio in [(0,1),(1,0.30),(2,0.07)]:
        cp=obj.copy();cp.data=obj.data.copy();export_col.objects.link(cp)
        name=('BFIMTallV03'+(f'_LOD{lod}' if lod else '')+('_Wat' if obj==water else ''))
        cp.name=cp.data.name=name
        if lod and obj==solid:
            activate(cp);mod=cp.modifiers.new('Distance simplification','DECIMATE');mod.ratio=ratio
            bpy.ops.object.modifier_apply(modifier=mod.name)
        export(cp,dest/(name+'.fbx'))
        stats.append({'name':name,'triangles':len(cp.data.polygons),'dimensions_m':list(cp.dimensions)})
        if lod:
            import shutil
            suffixes=['BaseColor'] if obj==water else ['BaseColor','MaskMap','ControlMask','Normal']
            for suffix in suffixes:shutil.copy2(dest/(basename+'_'+suffix+'.png'),dest/(name+'_'+suffix+'.png'))
        cp_mesh=cp.data
        bpy.data.objects.remove(cp,do_unlink=True)
        bpy.data.meshes.remove(cp_mesh)
    obj.name=obj.data.name=basename
    print('BF_EXPORTED '+basename,flush=True)
solid.hide_render=True;water.hide_render=True
for c in source_cols:c.hide_render=False
for o in source_objs:o.hide_render=False
export_col.hide_render=True
export_col.hide_viewport=True
scene['asset_status']='UV-mapped, baked, FBX export candidate; CS2 import validation pending'
(root/'Docs'/'export_check.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
scene.camera=bpy.data.objects['Camera overall']
scene.cycles.samples=48
bpy.ops.wm.save_as_mainfile(filepath=str(root/'Working'/'Buckingham_Fountain_in_Motion_export_v004.blend'))
print('BF_PREPARE_DONE',flush=True)


if args.render:
    scene.render.image_settings.file_format='JPEG';scene.render.image_settings.quality=92
    for cam,name in [('Camera overall','04_refined_day'),('Camera architectural detail','05_refined_detail')]:
        scene.camera=bpy.data.objects[cam];scene.render.filepath=str(root/'Outputs'/'Previews'/(name+'.jpg'))
        bpy.ops.render.render(write_still=True)
    scene.world.node_tree.nodes['Background'].inputs[1].default_value=0.025
    bpy.data.lights['Day sun'].energy=0.04
    for ring,r,z,n,power in [('lower',16.25,0.66,16,1050),('middle',9.55,2.82,12,700),('upper',2.85,5.10,8,230)]:
        for i in range(n):
            a=i*2*math.pi/n
            data=bpy.data.lights.new(f'Night {ring} {i:02d}','POINT')
            data.energy=power;data.color=(0.3,0.035,1) if i%3 else (1,0.48,0.12);data.shadow_soft_size=0.15
            lamp=bpy.data.objects.new(data.name,data);scene.collection.children['90 Presentation'].objects.link(lamp)
            lamp.location=(r*math.cos(a),r*math.sin(a),z)
    for i in range(4):
        a=math.pi/4+i*math.pi/2
        data=bpy.data.lights.new(f'Night sculpture {i}','POINT');data.energy=800;data.color=(0.95,0.63,0.2)
        lamp=bpy.data.objects.new(data.name,data);scene.collection.children['90 Presentation'].objects.link(lamp)
        lamp.location=(28*math.cos(a),28*math.sin(a),0.9)
    scene.camera=bpy.data.objects['Camera overall'];scene.render.filepath=str(root/'Outputs'/'Previews'/'06_night_lighting_study.jpg')
    bpy.ops.render.render(write_still=True)
    scene['night_status']='Blender lighting study; native CS2 lights still require verification'
    bpy.ops.wm.save_as_mainfile(filepath=str(root/'Working'/'Buckingham_Fountain_night_study.blend'))
    print('BF_NIGHT_STUDY_DONE',flush=True)
