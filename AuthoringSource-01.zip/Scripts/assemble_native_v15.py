from pathlib import Path
import zipfile,hashlib,json,re,uuid
R=Path(__file__).resolve().parents[1];G=Path(r'C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II')
S=R/"Assets/Package/V13/GPT's Buckingham Fountain in Motion.cok";old='5f712963e44ef0080613fde204a681bb3e8c496712fa4178a27d61835f8e12a2'
assert hashlib.sha256(S.read_bytes()).hexdigest()==old
A=G/'ChicagoAI/BFIMV15Authoring';T=R/'Assets/Source/NativeV15';T.mkdir(exist_ok=False)
root=(A/'BFIMV15RootExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV15RootExport',"GPT's Buckingham Fountain in Motion")
with zipfile.ZipFile(S) as z:child=z.read('BFIMNativeLightControllerV3.Prefab').decode('utf-8-sig')
assert root.count('CID:2e6a05d20a1b9c1ed52e969c2409b298')==4
assert root.count('CID:679d3c5e8a451361a17400090edcacd4')==1
assert root.count('"m_Duration": 120')==1 and child.count('"m_Duration": 120')==3
assert '"$rlength": 72' in child
replacements={'GPTBuckinghamFountainInMotionV3.Prefab':root.encode(),'package.deps.cid':uuid.uuid4().hex.encode()}
O=R/"Assets/Package/V15/GPT's Buckingham Fountain in Motion.cok";O.parent.mkdir(exist_ok=False)
kept={}
with zipfile.ZipFile(S) as a,zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
 assert a.testzip() is None
 for n in a.namelist():
  d=replacements.get(n,a.read(n));z.writestr(n,d)
  if n not in replacements:kept[n]=hashlib.sha256(d).hexdigest()
with zipfile.ZipFile(O) as z:
 assert z.testzip() is None
 ids=[z.read(n).decode('utf-8-sig').strip() for n in z.namelist() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n in z.namelist():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',z.read(n).decode('utf-8-sig')):assert cid in ids,(n,cid)
 for n,h in kept.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 assert 'StreamingData~/BFIMDetailsV10/TS512_MB3.MidMips' in z.namelist()
 deps=json.loads(z.read('package.deps').decode('utf-8-sig'));assert not deps['modDependencies'] and not deps['dlcDependencies']
 for n,d in replacements.items():(T/n).write_bytes(d)
receipt=dict(status='assembled-for-clean-load',path=str(O),sha256=hashlib.sha256(O.read_bytes()).hexdigest(),previousSha256=old,cycleSeconds=120,crossfadeSeconds=4,authoredBlackoutSeconds=5,nativeBlackoutSeconds=4,outerNativeEffect="FountainSmall",outerHeightTarget="approximately half former Fountain plume; visually checked",thinOuterMeshRemoved=True,fadeOutSeconds=3,fadeInSeconds=3,nativeWaterEffects=5,outerPlumes=4,lightEntries=72,crcPassed=True,preservedPayloads=kept)
(R/'Evidence/native-package-v015-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='preservedPayloads'}))
