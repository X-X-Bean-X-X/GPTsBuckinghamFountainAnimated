from pathlib import Path
import zipfile,json,hashlib,re,uuid
R=Path(__file__).resolve().parents[1]
h=lambda d:hashlib.sha256(d).hexdigest()
base=R/"Assets/Package/V18C/GPT's Buckingham Fountain, Animated.cok"
assert h(base.read_bytes())=='62986a77e249a87e3b39cc53e8c99c275a2cac0ff0d47ecaa2f4f1e2c8e6833f'
source=json.loads((R/'Evidence/v018e-perimeter-package.json').read_text());assert source['status']=='completed' and not source['mods'] and not source['dlc']
imported=json.loads((R/'Evidence/perimeter-v018e-native-import.json').read_text());assert imported['status']=='registered'
meshcid=next(x['id'].split()[0] for x in imported['prefabs'] if x['name']=='BFIMPerimeterV18E Mesh')
read=lambda b:json.loads(b.decode('utf-8-sig').replace('$fstrref:',''))
write=lambda j:re.sub(r'"(CID:[^"]+)"',r'$fstrref:"\1"',json.dumps(j,indent=4,ensure_ascii=False)).encode()
with zipfile.ZipFile(base) as a,zipfile.ZipFile(source['path']) as b:
 assert a.testzip() is None and b.testzip() is None
 data={n:a.read(n) for n in a.namelist()};before={n:h(v) for n,v in data.items()}
 root=data['GPTBuckinghamFountainInMotionV3.Prefab'].decode('utf-8-sig')
 root,n=re.subn(r'(CID:)75ec9070e571aca19b83018926b13820(".*?"m_Position":\s*\{.*?"y":\s*)0',lambda m:m[1]+meshcid+m[2]+'0.15',root,flags=re.S);assert n==1
 data['GPTBuckinghamFountainInMotionV3.Prefab']=root.encode()
 child=data['BFIMNativeLightControllerV3.Prefab'].decode('utf-8-sig')
 positions=json.loads((R/'Docs/perimeter-v018.json').read_text())['lights'];assert len(positions)==60
 warmcid=data['BFIMWarmPerimeterLightV18.Prefab.cid'].decode('utf-8-sig').strip();remaining=iter(positions)
 def lamp(m):
  p=next(remaining);s=m[2]
  for key,value in zip(['x','y','z'],p):s,n=re.subn(r'("'+key+r'":\s*)[-\d.eE+]+',lambda a:a[1]+str(value),s);assert n==1
  return m[1]+s+m[3]+'0'
 child,n=re.subn(r'("m_Effect":\s*\$fstrref:"CID:'+warmcid+r'".*?"m_PositionOffset":\s*\{)([^}]+)(\}.*?"m_ParentMesh":\s*)-1',lamp,child,flags=re.S);assert n==60
 assert child.count('"m_Duration": 120')==6
 data['BFIMNativeLightControllerV3.Prefab']=child.encode()
 warm=data['BFIMWarmPerimeterLightV18.Prefab'].decode('utf-8-sig');assert '"m_LodBias": 0' in warm and '"m_DisableDistanceCulling": false' in warm
 data['BFIMWarmPerimeterLightV18.Prefab']=warm.replace('"m_LodBias": 0','"m_LodBias": -3').replace('"m_DisableDistanceCulling": false','"m_DisableDistanceCulling": true').encode()
 data['package.deps.cid']=uuid.uuid4().hex.encode()
 for n in b.namelist():
  if n in ('package.deps','package.deps.cid','BFIMPerimeterV18EPayload.Prefab','BFIMPerimeterV18EPayload.Prefab.cid'):continue
  target=n.replace('StreamingData~/TS512_MB3.MidMips','StreamingData~/BFIMPerimeterV18E/TS512_MB3.MidMips')
  assert target not in data,target
  data[target]=b.read(n)
 changed={'GPTBuckinghamFountainInMotionV3.Prefab','BFIMNativeLightControllerV3.Prefab','BFIMWarmPerimeterLightV18.Prefab','package.deps.cid'}
 for n,digest in before.items():
  if n not in changed:assert h(data[n])==digest,n
 ids=[v.decode('utf-8-sig').strip() for n,v in data.items() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n,v in data.items():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',v.decode('utf-8-sig')):assert cid in ids,(n,cid)
 O=R/"Assets/Package/V18E/GPT's Buckingham Fountain, Animated.cok";O.parent.mkdir(exist_ok=False)
 with zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
  for n,v in data.items():z.writestr(n,v)
with zipfile.ZipFile(O) as z:assert z.testzip() is None
receipt=dict(status='assembled-not-yet-reload-verified',path=str(O),sha256=h(O.read_bytes()),warmLights=60,temperature=2700,oldSaveNameAlias=True,lotCells=[16,23],pavingYOffset=.15,meshCID=meshcid,existingWaterAndLightCycleUnchanged=True,crcPassed=True)
(R/'Evidence/native-package-v018e-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
