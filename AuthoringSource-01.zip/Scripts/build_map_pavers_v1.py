from pathlib import Path
import bpy, math, json, shutil
import numpy as np
from mathutils import Vector
R=Path(__file__).resolve().parents[1];D=R/'Assets/Import/BFIMMapPaversV1';D.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(R/'Working/Buckingham_Fountain_in_Motion_source_v003_taller_tiers.blend'))
coping=bpy.data.objects['Mapped outer basin coping - 85.344 m'];n=len(coping.data.vertices)//7
outline=[(coping.matrix_world@v.co).xy[:] for v in list(coping.data.vertices)[:n]]
# Surveyed path enclosure: retain existing diagonal endpoints and close the missing side.
world=[(1740.881,-630.669434),(1752.71973,-630.388062),(1808.721,-694.155151),(1809.32593,-742.976563),(1762.73767,-808.1756),(1739.05139,-808.7828),(1686.403,-741.559448),(1685.56955,-694.155151)]
angle=2*math.asin(.009526444);co=math.cos(angle);si=math.sin(angle)
polygon=[]
for x,z in world:
 dx=x-1749.3396;dz=z+719.9702;polygon.append((-(co*dx-si*dz),-(si*dx+co*dz)))
if sum(polygon[i][0]*polygon[(i+1)%8][1]-polygon[(i+1)%8][0]*polygon[i][1] for i in range(8))<0:polygon.reverse()
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def boundary(p):
 r=math.hypot(*p);d=(p[0]/r,p[1]/r);hits=[]
 for a,b in zip(polygon,polygon[1:]+polygon[:1]):
  e=(b[0]-a[0],b[1]-a[1]);den=cross(d,e)
  if abs(den)<1e-9:continue
  t=cross(a,e)/den;u=cross(a,d)/den
  if t>0 and -.0001<=u<=1.0001:hits.append(t)
 return min(hits)-1.1 # pavers meet the inner side of the pedestrian path
verts=[];faces=[];bands=[]
def mesh(v,f,band):
 if band!=0:return
 k=len(verts);verts.extend(v);faces.extend([tuple(k+i for i in q) for q in f]);bands.extend([band]*len(f))
def box(center,size,band):
 x,y,z=center;a,b,c=[s/2 for s in size];v=[(x+i*a,y+j*b,z+k*c) for k in [-1,1] for j in [-1,1] for i in [-1,1]]
 mesh(v,[(0,2,3,1),(4,5,7,6),(0,1,5,4),(2,6,7,3),(0,4,6,2),(1,3,7,5)],band)
def tube(points,r,band,sides=8):
 v=[];f=[]
 for j,p in enumerate(points):
  tang=Vector(points[min(j+1,len(points)-1)])-Vector(points[max(0,j-1)]);tang.normalize();a=tang.cross(Vector((0,0,1)))
  if a.length<.001:a=tang.cross(Vector((0,1,0)))
  a.normalize();b=tang.cross(a)
  for k in range(sides):v.append(tuple(Vector(p)+r*(math.cos(k*math.tau/sides)*a+math.sin(k*math.tau/sides)*b)))
  if j:
   for k in range(sides):q=(j-1)*sides+k;qq=(j-1)*sides+(k+1)%sides;f.append((q,qq,qq+sides,q+sides))
 mesh(v,f,band)
inner=[];outer=[];clearances=[]
for p in outline:
 r=math.hypot(*p);br=boundary(p);clearances.append(br-r-3.18)
 inner.append((p[0]*(r+3.19)/r,p[1]*(r+3.19)/r,.025));outer.append((p[0]*br/r,p[1]*br/r,.025))
assert min(clearances)>1,min(clearances)
mesh(inner+outer,[(i+n,(i+1)%n+n,(i+1)%n,i) for i in range(n)],0)
# Small bronze lanterns on the outer fence at a regular spacing.
rail=[Vector((p[0]*(1+2.72/math.hypot(*p)),p[1]*(1+2.72/math.hypot(*p)),.06)) for p in outline]
lengths=[(rail[(i+1)%n]-rail[i]).length for i in range(n)];total=sum(lengths)
def at(s):
 for i,l in enumerate(lengths):
  if s<=l:return rail[i].lerp(rail[(i+1)%n],s/l)
  s-=l
 return rail[0]
lights=[];count=60
for i in range(count):
 p=at(i*total/count);x,y=p.x,p.y
 tube([(x,y,.05),(x,y,1.20)],.035,1)
 box((x,y,.96),(.23,.23,.32),2)
 for z in [.78,1.14]:box((x,y,z),(.31,.31,.055),1)
 for dx in [-.12,.12]:
  for dy in [-.12,.12]:tube([(x+dx,y+dy,.79),(x+dx,y+dy,1.15)],.012,1,6)
 lights.append([-x,1.17,-y])
me=bpy.data.meshes.new('BFIMMapPaversV1');me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new('BFIMMapPaversV1',me);bpy.context.scene.collection.objects.link(o)
uv=me.uv_layers.new(name='UVMap')
for face,band in zip(me.polygons,bands):
 for li in face.loop_indices:
  v=me.vertices[me.loops[li].vertex_index].co
  # Continuous world-scaled paving uses lower 75 percent; fixtures occupy upper atlas strips.
  uv.data[li].uv=(v.x/132+.5,v.y/270+.375) if band==0 else (.1+(v.x*.07% .8),.80 if band==1 else .94)
res=2048;yy,xx=np.mgrid[0:res,0:res];rng=np.random.default_rng(18)
pix=np.ones((res,res,4),np.float32);row=(yy//6);col=((xx+((row%2)*6))//12)
grout=((yy%6)<1)|(((xx+(row%2)*6)%12)<1)
variation=.83+.23*rng.random((343,173))[row,col]
stone=np.array([.32,.22,.15]);pix[:,:,:3]=stone[None,None,:]*variation[:,:,None]*(.94+.12*rng.random((res,res,1)))
pix[grout,:3]*=.55;pix[int(res*.76):int(res*.88),:,:3]=[.075,.065,.045];pix[int(res*.88):,:,:3]=[.95,.56,.18]
def save(name,arr,non=False):
 im=bpy.data.images.new(name,width=res,height=res,alpha=True);im.colorspace_settings.name='Non-Color' if non else 'sRGB';im.pixels.foreach_set(arr.ravel());im.filepath_raw=str(D/(name+'.png'));im.file_format='PNG';im.save();return im
base=save('BFIMMapPaversV1_BaseColor',pix)
mask=np.zeros_like(pix);mask[:,:,3]=.25;mask[int(res*.76):int(res*.88),:,0]=.65;mask[int(res*.76):int(res*.88),:,3]=.45
save('BFIMMapPaversV1_MaskMap',mask,True);save('BFIMMapPaversV1_ControlMask',np.zeros_like(pix),True)
normal=np.ones_like(pix);normal[:,:,:2]=.5;save('BFIMMapPaversV1_Normal',normal,True)
mat=bpy.data.materials.new('BFIMMapPaversV1');mat.use_nodes=True;tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=base;mat.node_tree.links.new(tex.outputs['Color'],mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color']);me.materials.append(mat)
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
o.name=o.data.name='SOURCE_BFIMMapPaversV1'
checks=[]
for lod,ratio in [(0,1),(1,.55),(2,.18)]:
 cp=o.copy();cp.data=o.data.copy();bpy.context.scene.collection.objects.link(cp);name='BFIMMapPaversV1'+('_LOD'+str(lod) if lod else '');cp.name=cp.data.name=name
 bpy.ops.object.select_all(action='DESELECT');cp.select_set(True);bpy.context.view_layer.objects.active=cp
 if lod:m=cp.modifiers.new('LOD','DECIMATE');m.ratio=ratio;bpy.ops.object.modifier_apply(modifier=m.name)
 m=cp.modifiers.new('Triangles','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=m.name)
 bpy.ops.export_scene.fbx(filepath=str(D/(name+'.fbx')),use_selection=True,object_types={'MESH'},apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_tspace=True,add_leaf_bones=False,bake_anim=False)
 if lod:
  for suffix in ['BaseColor','MaskMap','ControlMask','Normal']:shutil.copy2(D/('BFIMMapPaversV1_'+suffix+'.png'),D/(name+'_'+suffix+'.png'))
 checks.append({'name':name,'triangles':len(cp.data.polygons),'dimensions':list(cp.dimensions)});bpy.data.objects.remove(cp,do_unlink=True)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Working/Buckingham_Fountain_Map_Only_Pavers.blend'))
(R/'Docs/map-pavers-v1.json').write_text(json.dumps({'lights':lights,'colorTemperature':2700,'worldEnclosure':world,'localEnclosure':polygon,'minimumApronWidth':min(clearances),'meshes':checks},indent=2))
print(json.dumps(checks),flush=True)




