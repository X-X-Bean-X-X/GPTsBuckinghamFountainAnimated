from pathlib import Path
import zipfile,json,hashlib,re,uuid
R=Path(__file__).resolve().parents[1];G=Path('C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II')
h=lambda d:hashlib.sha256(d).hexdigest()
base=R/"Assets/Package/GPT's Buckingham Fountain in Motion.cok"
assert h(base.read_bytes())=='5f712963e44ef0080613fde204a681bb3e8c496712fa4178a27d61835f8e12a2'
source=json.loads((R/'Evidence/v014-outer-jets-package.json').read_text());assert source['status']=='completed' and not source['mods'] and not source['dlc']
root=(G/'ChicagoAI/BFIMV14Authoring/BFIMV14RootExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV14RootExport',"GPT's Buckingham Fountain in Motion").encode()
assert root.count(b'CID:679d3c5e8a451361a17400090edcacd4')==1
assert b'CID:78635ca43025508d74675c9037c880b0' in root
assert b'"m_Duration": 120' in root
T=R/'Assets/Source/NativeV14';T.mkdir(exist_ok=False);(T/'GPTBuckinghamFountainInMotionV3.Prefab').write_bytes(root)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(source['path']) as b:
 assert a.testzip() is None and b.testzip() is None
 data={n:a.read(n) for n in a.namelist()}
 before={n:h(v) for n,v in data.items()}
 data['GPTBuckinghamFountainInMotionV3.Prefab']=root;data['package.deps.cid']=uuid.uuid4().hex.encode()
 added={}
 for n in b.namelist():
  if n in ('package.deps','package.deps.cid','BFIMOuterJetsV14Payload.Prefab','BFIMOuterJetsV14Payload.Prefab.cid'):continue
  target=n.replace('StreamingData~/TS512_MB3.MidMips','StreamingData~/BFIMOuterJetsV14/TS512_MB3.MidMips')
  assert target not in data,target
  data[target]=b.read(n);added[target]=h(data[target])
 for n,digest in before.items():
  if n not in ('GPTBuckinghamFountainInMotionV3.Prefab','package.deps.cid'):assert h(data[n])==digest,n
 ids=[v.decode('utf-8-sig').strip() for n,v in data.items() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n,v in data.items():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',v.decode('utf-8-sig')):assert cid in ids,(n,cid)
 O=R/"Assets/Package/V14/GPT's Buckingham Fountain in Motion.cok";O.parent.mkdir(exist_ok=False)
 with zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
  for n,v in data.items():z.writestr(n,v)
with zipfile.ZipFile(O) as z:assert z.testzip() is None
receipt=dict(status='assembled',path=str(O),sha256=h(O.read_bytes()),previousSha256=h(base.read_bytes()),outerJetHeightMetres=12.5,outerBundles=4,centralNativeEffects=1,lightingPreservedByteForByte=True,cycleSeconds=120,addedFiles=added,crcPassed=True)
(R/'Evidence/native-package-v014-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='addedFiles'}))
