from pathlib import Path
import zipfile,hashlib,json,re,uuid,shutil
R=Path(__file__).resolve().parents[1]
G=Path(r"C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II")
S=R/"Assets/Package/V4/GPT's Buckingham Fountain in Motion.cok"
D=G/'.packages/BFIMDetailsV10Payload.cok'
assert hashlib.sha256(S.read_bytes()).hexdigest()=='4c4dfec85bc958fac554f69579762a8af1fc19cb24a3b995ee52bc73d570f8b3'
assert json.loads((R/'Evidence/v010-details-package.json').read_text())['status']=='completed'
O=R/"Assets/Package/V10-Candidate/GPT's Buckingham Fountain in Motion.cok"
O.parent.mkdir(parents=True,exist_ok=True);assert not O.exists()
A=G/'ChicagoAI/BFIMDetailsV5'
T=R/'Assets/Source/NativeV10-Candidate';T.mkdir(parents=True,exist_ok=False)
root=(A/'BFIMV5VisualPreview.Prefab').read_text(encoding='utf-8-sig')
child=(A/'BFIMV5LightController.Prefab').read_text(encoding='utf-8-sig')
assert root.count('CID:2e6a05d20a1b9c1ed52e969c2409b298')==0
assert root.count('CID:679d3c5e8a451361a17400090edcacd4')==1
assert '"m_LotWidth": 12' in root and '"m_LotDepth": 12' in root
assert root.count('CID:ec508012e728b5c4daecc235e330c1d4')==1
root=root.replace('BFIM V5 Visual Preview',"GPT's Buckingham Fountain in Motion").replace('CID:ec508012e728b5c4daecc235e330c1d4','CID:aaadcfeaacc3958287f5f882d3294c29')
child=child.replace('BFIM V5 Light Controller Preview','BFIMNativeLightControllerV3')
assert '"$rlength": 72' in child
replacements={'GPTBuckinghamFountainInMotionV3.Prefab':root.encode('utf8'),'BFIMNativeLightControllerV3.Prefab':child.encode('utf8'),'package.deps.cid':uuid.uuid4().hex.encode()}
kept={};added={};renamed={};entries={}
with zipfile.ZipFile(S) as s,zipfile.ZipFile(D) as d:
 assert s.testzip() is None and d.testzip() is None
 for n in s.namelist():
  v=replacements.get(n,s.read(n));entries[n]=v
  if n not in replacements: kept[n]=hashlib.sha256(v).hexdigest()
 for n in d.namelist():
  if n in ['package.deps','package.deps.cid','BFIMDetailsV10Payload.Prefab','BFIMDetailsV10Payload.Prefab.cid']:continue
  dest=n
  if n.startswith('StreamingData~/TS512_MB3.MidMips'):
   dest=n.replace('TS512_MB3','BFIMDetailsV10_TS512_MB3');renamed[n]=dest
  assert dest not in entries,dest
  entries[dest]=d.read(n);added[dest]=hashlib.sha256(entries[dest]).hexdigest()
with zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
 for n,v in entries.items():z.writestr(n,v)
with zipfile.ZipFile(O) as z:
 assert z.testzip() is None
 cids=[z.read(n).decode('utf-8-sig').strip() for n in z.namelist() if n.endswith('.cid')]
 assert len(set(cids))==len(cids),'duplicate CIDs'
 for n in z.namelist():
  if n.endswith('.Prefab'):
   txt=z.read(n).decode('utf-8-sig')
   for cid in re.findall(r'CID:([a-f0-9]{32})',txt): assert cid in cids,(n,cid)
 assert z.read('GPTBuckinghamFountainInMotionV3.Prefab.cid').decode().strip()=='8c4ee53137be5794b8f4cc6644b1f732'
 assert z.read('BFIMNativeLightControllerV3.Prefab.cid').decode().strip()=='aaadcfeaacc3958287f5f882d3294c29'
 assert not any(n.endswith('.dll') for n in z.namelist())
 for n,h in kept.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 for n,h in added.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 deps=json.loads(z.read('package.deps').decode('utf-8-sig'));assert not deps['modDependencies'] and not deps['dlcDependencies']
 for n,v in replacements.items():(T/n).write_bytes(v)
 shutil.copy2(D,T/D.name)
receipt={'status':'candidate-assembled-not-visually-accepted','path':str(O),'sha256':hashlib.sha256(O.read_bytes()).hexdigest(),'bytes':O.stat().st_size,'entries':len(entries),'crcPassed':True,'allCustomPrefabReferencesIncluded':True,'nativeParticleSources':1,'authoredArcPaths':132,'lightEntries':72,'preservedPayloads':kept,'addedPayloads':added,'renamedEntries':renamed,'dependencies':deps,'assembly':'Merged byte-identical native exports; replaced native-serialized root and light controller; preserved motion asset IDs. Requires clean-load and visual testing.'}
(R/'Evidence/native-package-v010-candidate-assembly.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k not in ['preservedPayloads','addedPayloads']}))
