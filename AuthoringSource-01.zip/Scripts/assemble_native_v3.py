from pathlib import Path
import zipfile,hashlib,json,re,uuid
R=Path(__file__).resolve().parents[1]
G=Path(r'C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II')
S=G/"StreamingData~/GPT's Buckingham Fountain in Motion.cok"
assert hashlib.sha256(S.read_bytes()).hexdigest()=='92f8f95679b9e7f65b41cd8ddc69a30d3150747ee71958276648d73dfb407704'
A=Path(r'H:/Games/GPT, Chicago AI Project/ACM - Maps/Chicago GPT/Assets/ChicagoAI/BFIMNativeMotionV3')
O=R/"Assets/Package/V3/GPT's Buckingham Fountain in Motion.cok"
O.parent.mkdir(parents=True,exist_ok=True)
assert not O.exists()
removed=[];kept={}
with zipfile.ZipFile(S) as old,zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as new:
 for info in old.infolist():
  if info.filename.startswith('BFIMNativeNight'):
   removed.append(info.filename);continue
  data=old.read(info.filename)
  if info.filename=='package.deps.cid':data=uuid.uuid4().hex.encode()
  new.writestr(info,data)
  if info.filename!='package.deps.cid':kept[info.filename]=hashlib.sha256(data).hexdigest()
 assert len(removed)==10
 files=list(A.iterdir());assert len(files)==10 and all(p.name.endswith(('.Prefab','.Prefab.cid')) for p in files)
 for f in files:new.write(f,f.name,compress_type=zipfile.ZIP_STORED)
with zipfile.ZipFile(O) as z:
 assert z.testzip() is None and len(z.namelist())==50
 for n,h in kept.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 ids={z.read(n).decode('utf-8-sig').strip() for n in z.namelist() if n.endswith('.cid')}
 for n in z.namelist():
  if not n.endswith('.Prefab'):continue
  t=z.read(n).decode('utf-8-sig')
  for cid in re.findall(r'CID:([a-f0-9]{32})',t):assert cid in ids,(n,cid)
 root=z.read('GPTBuckinghamFountainInMotionV3.Prefab').decode('utf-8-sig')
 assert '"m_LotWidth": 11' in root and '"m_LotDepth": 11' in root
 assert root.count('UnityGUID:9df86ceecc42a464986e80c3ba3c274a')==1
 assert root.count('UnityGUID:6ee87921a1dc0404888222f31fb94335')==12
 assert z.read('BFIMNativeLightControllerV3.Prefab').decode('utf-8-sig').count('"m_Effect":')==36
 deps=json.loads(z.read('package.deps').decode('utf-8-sig'));assert deps['modDependencies']==[] and deps['dlcDependencies']==[]
receipt={'status':'assembled-and-verified','method':'Native serialized V3 prefabs with byte-identical verified native mesh and material payload','path':str(O),'sha256':hashlib.sha256(O.read_bytes()).hexdigest(),'bytes':O.stat().st_size,'entries':50,'crcPassed':True,'allCustomPrefabReferencesIncluded':True,'preservedPayloads':kept,'removedV2Prefabs':removed,'dependencies':deps}
(R/'Evidence/native-package-v003-assembly.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k not in ['preservedPayloads','removedV2Prefabs']}))
