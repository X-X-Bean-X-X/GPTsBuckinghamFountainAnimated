from pathlib import Path
import hashlib, json, re, uuid, zipfile

R = Path(__file__).resolve().parents[1]
sha = lambda data: hashlib.sha256(data).hexdigest()
base = R / "Assets/Package/V18E/GPT's Buckingham Fountain, Animated.cok"
assert sha(base.read_bytes()) == '063ee769b3a330c2cd51b73b765d7d2dd02a9aa0290925bd3bcd5c0f2cc5dc4d'
source = json.loads((R / 'Evidence/v019-lanterns-package.json').read_text())
assert source['status'] == 'completed' and not source['mods'] and not source['dlc']
imported = json.loads((R / 'Evidence/lanterns-v019-native-import.json').read_text())
assert imported['status'] == 'registered'
meshcid = next(x['id'].split()[0] for x in imported['prefabs'] if x['name'] == 'BFIMLanternsV19 Mesh')
with zipfile.ZipFile(base) as old, zipfile.ZipFile(source['path']) as payload:
    assert old.testzip() is None and payload.testzip() is None
    data = {n: old.read(n) for n in old.namelist()}
    before = {n: sha(v) for n, v in data.items()}
    rootname = 'GPTBuckinghamFountainInMotionV3.Prefab'
    root = data[rootname].decode('utf-8-sig')
    assert root.count('CID:809b4a660c8d3c54b7c1c534d341eaa9') == 1
    data[rootname] = root.replace('CID:809b4a660c8d3c54b7c1c534d341eaa9', 'CID:' + meshcid).encode()
    data['package.deps.cid'] = uuid.uuid4().hex.encode()
    for name in payload.namelist():
        if name in ('package.deps', 'package.deps.cid', 'BFIMLanternsV19Payload.Prefab', 'BFIMLanternsV19Payload.Prefab.cid'):
            continue
        target = name.replace('StreamingData~/TS512_MB3.MidMips', 'StreamingData~/BFIMLanternsV19/TS512_MB3.MidMips')
        assert target not in data, target
        data[target] = payload.read(name)
    for name, digest in before.items():
        if name not in (rootname, 'package.deps.cid'):
            assert sha(data[name]) == digest, name
    ids = [v.decode('utf-8-sig').strip() for n, v in data.items() if n.endswith('.cid')]
    assert len(ids) == len(set(ids))
    for name, value in data.items():
        if name.endswith('.Prefab'):
            for cid in re.findall(r'CID:([a-f0-9]{32})', value.decode('utf-8-sig')):
                assert cid in ids, (name, cid)
    output = R / "Assets/Package/V19/GPT's Buckingham Fountain, Animated.cok"
    output.parent.mkdir(exist_ok=False)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as package:
        for name, value in data.items():
            package.writestr(name, value)
with zipfile.ZipFile(output) as package:
    assert package.testzip() is None
receipt = dict(status='assembled-not-installed-or-reload-verified', path=str(output), sha256=sha(output.read_bytes()),
               meshCID=meshcid, paverSurfaceAssigned=False, warmLights=60,
               originalGeometryWaterAndLightingUnchanged=True, crcPassed=True)
(R / 'Evidence/native-package-v019-assembly.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt))
