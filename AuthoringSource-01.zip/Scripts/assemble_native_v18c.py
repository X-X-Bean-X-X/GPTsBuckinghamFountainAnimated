from pathlib import Path
import zipfile,json,hashlib,re,uuid
R=Path(__file__).resolve().parents[1];G=Path('C:/Users/YOUR_USER/AppData/LocalLow/Colossal Order/Cities Skylines II')
h=lambda d:hashlib.sha256(d).hexdigest()
base=R/"Assets/Package/V18/GPT's Buckingham Fountain, Animated.cok"
assert h(base.read_bytes())=='00271deaf47ac124fdc4c8e35577bce02b3215d9424f3db20b3299edfb4f5af2'
source=json.loads((R/'Evidence/v018c-perimeter-package.json').read_text());assert source['status']=='completed' and not source['mods'] and not source['dlc']
root=(G/'ChicagoAI/BFIMV18CAuthoring/BFIMV18CRootExport.Prefab').read_text(encoding='utf-8-sig').replace('BFIMV18CRootExport',"GPT's Buckingham Fountain, Animated").encode()
assert b'75ec9070e571aca19b83018926b13820' in root and b'ObsoleteIdentifiers' in root
assert b'"m_LotWidth": 16' in root and b'"m_LotDepth": 23' in root
with zipfile.ZipFile(base) as a,zipfile.ZipFile(source['path']) as b:
 assert a.testzip() is None and b.testzip() is None
 data={n:a.read(n) for n in a.namelist()};before={n:h(v) for n,v in data.items()}
 data['GPTBuckinghamFountainInMotionV3.Prefab']=root;data['package.deps.cid']=uuid.uuid4().hex.encode()
 for n in b.namelist():
  if n in ('package.deps','package.deps.cid','BFIMPerimeterV18CPayload.Prefab','BFIMPerimeterV18CPayload.Prefab.cid'):continue
  target=n.replace('StreamingData~/TS512_MB3.MidMips','StreamingData~/BFIMPerimeterV18C/TS512_MB3.MidMips')
  assert target not in data,target
  data[target]=b.read(n)
 for n,digest in before.items():
  if n not in ('GPTBuckinghamFountainInMotionV3.Prefab','package.deps.cid'):assert h(data[n])==digest,n
 ids=[v.decode('utf-8-sig').strip() for n,v in data.items() if n.endswith('.cid')];assert len(ids)==len(set(ids))
 for n,v in data.items():
  if n.endswith('.Prefab'):
   for cid in re.findall(r'CID:([a-f0-9]{32})',v.decode('utf-8-sig')):assert cid in ids,(n,cid)
 O=R/"Assets/Package/V18C/GPT's Buckingham Fountain, Animated.cok";O.parent.mkdir(exist_ok=False)
 with zipfile.ZipFile(O,'w',compression=zipfile.ZIP_STORED) as z:
  for n,v in data.items():z.writestr(n,v)
with zipfile.ZipFile(O) as z:assert z.testzip() is None
receipt=dict(status='assembled-not-yet-reload-verified',path=str(O),sha256=h(O.read_bytes()),warmLights=60,temperature=2700,oldSaveNameAlias=True,lotCells=[16,23],existingWaterAndLightCycleUnchanged=True,crcPassed=True)
(R/'Evidence/native-package-v018c-assembly.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
